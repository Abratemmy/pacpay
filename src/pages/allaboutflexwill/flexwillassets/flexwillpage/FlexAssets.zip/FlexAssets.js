import React, {useState, useEffect} from 'react'
import Interface from '../../../../components/flexwillinterface/interface';
import assetrsa from "../../../../assets/assetrsa.png";
import assetcash from "../../../../assets/assetcash.png";
import { NavLink, useNavigate } from 'react-router-dom';
import FlexRsa from './flexRsa';
import rsavalidation from "./flexRsavalidation"
import MainModal from '../../../../components/mainModal/MainModal';
import Beneficiary from '../../../../components/beneficiarypop/beneficiary';
import { IoMdAddCircleOutline } from "react-icons/io";
import Flexcashlanding from './cashinnabkLanding';
import Distributeasset1 from './distributeasset1';
import { AiFillStar } from "react-icons/ai";
import { BsArrowUpRight } from "react-icons/bs"

function FlexAssets() {
    const [toggleState, setToggleState] = useState(1);
    const toggleTab = (index) => {
        setToggleState(index);
    }

    const initialstate={
      cashInBank:[]
    }
    const [assetData, setAssetData] = useState(initialstate);

    const rsaInital = {
      pfaAdmin:"",
      penNumber:"",
      checked:"",
      beneficiaries:[]
    }

    const [rsaData, setRsaData] = useState(rsaInital)
    
    const [errors, setErrors] = useState({});

    const [assignBeneficiary, setAssignBeneficiary] = useState(false)
    const assignRsaBen = () => {
      const rsaError = rsavalidation(rsaData);
        setErrors(rsaError);
        if (Object.keys(rsaError).length > 0) {
            console.log("error")
        } else {
          let rsa = {}
          rsa = rsaData
          setAssetData(asset => ({
              ...asset,
              rsa
          }))
          setAssignBeneficiary(!assignBeneficiary)
         
      }   
    }    
    const addBeneficiary = ()=>{
      setToggleState(2)
    }

    // code to assign beneficiary below
    //I also want to append the result to rsaData

    const selectedBeneficiary = JSON.parse(localStorage.getItem("BeneficiayList"));
    console.log("selected", selectedBeneficiary)

    // const [values, setValues] = useState({
    //     description: "",
    //     title:selectedBeneficiary.title,
    //     fullName: selectedBeneficiary.fullName,
    //     relationship:"child",
    //     address:selectedBeneficiary.contactAddress,
    //     city:selectedBeneficiary.city,
    //     percentage:""
    // });

    const [rsaBeneficiary, setRsaBeneficiary] = useState([selectedBeneficiary])



  const handleFormChange  = (event, id) => {
    const { value } = event.target.percentage;
    setRsaBeneficiary((room) =>
      room?.map((list, index) =>
        index === id ? { ...list, room: value } : list
      )
    );
  };
  const handleError = (targets) => {
    let errorsValue = {};
    if (!targets.percentage) errorsValue.percentage = "percentage  is required";


    if (Object.keys(errorsValue).length > 0) setErrors({ ...errorsValue });
    else setErrors({});

    return Object.keys(errorsValue).length;

  };

  const navigate = useNavigate()

  const handleSubmit = (ev) => {
    ev.preventDefault()
    let v = handleError(rsaBeneficiary);
    console.log("submitted", rsaBeneficiary);
        navigate("/flex_will_distribute_asset2")
    
  }

  useEffect(() => {
      setAssetData(assetData)      
      console.log("assetData1", (assetData));
  }, [assetData])

  return (
    <Interface>
      <div className='distribute-2'>
        <div className='distributeAssets'>
          {
            toggleState === 1 || toggleState === 2 ? " " :
            <div className="bloc-tabs disable-bloc">
              <div className={toggleState === 1 ? "tabs active-tabs" : "tabs"} onClick={() => toggleTab(1)}><span><img src={assetrsa} alt="" /> </span>RSA</div>
              <div className={toggleState === 2 ? "tabs active-tabs" : "tabs"} onClick={() => toggleTab(2)}><span><img src={assetcash} alt="" /></span> Cash in Bank</div>
            </div>
          }
          
          <div className="content-tabs" >
            <div className={toggleState === 1 ? "content active-content" : "content"}>
                <FlexRsa rsaData={rsaData} setRsaData={setRsaData} errors={errors} />

                <div className='button' style={{ textAlign: "right", paddingRight: "60px", marginTop: "30px" }}>
                    <span onClick={assignRsaBen} className="general-btn" style={{ border: "none" }}>
                        Assign Beneficiary
                    </span>
                </div>


                <MainModal trigger={assignBeneficiary} setTrigger={setAssignBeneficiary}>
                    <div className='modalContent'>
                        <Beneficiary  setToggle={addBeneficiary}  />
                          
                    </div>
                </MainModal>
            </div>

            <div className={toggleState === 2 ? "content active-content" : "content"}>
              <Distributeasset1 backBtn={()=> setToggleState(1)}>
                <form onSubmit={handleSubmit} style={{ position: "relative" }}>
                      <div className='asset1'>
                          {rsaBeneficiary.map((selected, index) => {
                              return(
                                  <div className='content' key={index}>
                                      <div className='text'><AiFillStar className="icon" /><span>{selected.fullName}</span></div>
                                      <div className='input'><input type="number" className='input'name="percentage" value={selected.percentage} onChange={event => handleFormChange(index, event)} /></div>
                                  </div>
                              )
                          })}

                          
                          <div className='description'>
                              <label>Description</label>
                              <div className="input-group ">
                                  <textarea className="form-control assetinputfield" name="description"  placeholder="description" rows="5"></textarea>
                              </div>
                            
                          </div>

                          <div className='asset-btn'>
                              <div className='asset1last'>
                                  <div className='ps'>PS: You don’t want to share your asset now? you can <NavLink to="/flex_will_distribute_asset2" style={{ background: "transparent", textDecoration: "none" }}><span>Skip <BsArrowUpRight className="icon" /> </span></NavLink> </div>
                                  <div className='asset-button'><button type="submit" className="asset-nav" style={{ border: "none" }}>Submit</button></div>
                                  {errors ? <p className='error'> {errors.percentage}</p> : ""}
                              </div>
                          </div>
                          
                      </div>
                  </form>
              </Distributeasset1>

            </div>
          </div>
        </div>
      </div>
    
    </Interface>
  )
}

export default FlexAssets